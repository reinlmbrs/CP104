"""
-------------------------------------------------------
[Assignment 7, Task 5]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-18"
-------------------------------------------------------
"""
# Imports
from functions import verify_sorted

# Inputs
numbers = [23, 41, 99]
numbers2 = [99, 23, 41]

# Outputs
in_order, index = verify_sorted(numbers)
print(verify_sorted([23, 41, 99]))
print(verify_sorted([99, 23, 41]))
print(verify_sorted([1, 2, 3]))
