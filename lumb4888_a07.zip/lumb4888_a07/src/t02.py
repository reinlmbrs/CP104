"""
-------------------------------------------------------
[Assignment 7, Task 2]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-18"
-------------------------------------------------------
"""
# Imports
from functions import list_positives

# Outputs
number_list = list_positives()

print(number_list)
