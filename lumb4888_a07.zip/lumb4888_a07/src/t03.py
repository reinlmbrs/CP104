"""
-------------------------------------------------------
[Assignment 7, Task 3]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-18"
-------------------------------------------------------
"""
# Imports
from functions import get_indexes

# Inputs
numbers = input("List of values: ")
target_number = input("Value to look for in the list: ")

# Outputs
index_list = get_indexes(numbers, target_number)

print(index_list)
