"""
-------------------------------------------------------
[Functions Module]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-18"
-------------------------------------------------------
"""
# t01


def list_factors(number):
    """
    -------------------------------------------------------
    User inputs integer and the program returns a list of the
    factors that make up that number excepting the number itself.
    Use: factor = list_factors(number)
    -------------------------------------------------------
    Parameters:
        number - An integer (int > 0)
    Returns:
        factor - A list of factors of the integer (int > 0)
    ------------------------------------------------------
    """
    factor = []

    for i in range(1, number):
        if number % i == 0:
            factor.append(i)

    return factor


# t02
def list_positives():
    """
    -------------------------------------------------------
    Gets a list of positive numbers from a user.
    Negative numbers are ignored. Enter 0 to stop entries.
    Use: number_list = list_positives()
    -------------------------------------------------------
    Returns:
        number_list - A list of positive integers (list of int)
    ------------------------------------------------------
    """
    number_list = []

    numbers = int(input("Enter a positive number (0 to stop): "))

    while numbers != 0:
        if numbers > 0:
            number_list.append(numbers)

        numbers = int(input("Enter next positive number: "))

    return number_list


# t03
def get_indexes(numbers, target_number):
    """
    -------------------------------------------------------
    Finds the indexes of target_number in numbers.
    Use: index_list = get_indexes(numbers, target_number)
    -------------------------------------------------------
    Parameters:
        numbers - list of values (list)
        target_number - value to look for in num_list (*)
    Returns:
        index_list - list of indexes of target_number (list of int)
    -------------------------------------------------------
    """
    index_list = []

    for i in range(len(numbers)):
        if numbers[i] == target_number:
            index_list.append(i)

    return index_list

# t04


def list_subtract(minuend, subtrahend):
    """
    -------------------------------------------------------
    Alters the contents of minuend so that it does not contain
    any values in subtrahend.
    i.e. the values in the first list that appear in the second list
    are removed from the first list.
    Use: list_subtract(minuend, subtrahend)
    -------------------------------------------------------
    Parameters:
        minuend - a list of values (list)
        subtrahend - a list of values to not include in difference (list)
    Returns:
        None
    ------------------------------------------------------
    """
    for value in subtrahend:
        index_list = get_indexes(minuend, value)
        for index in reversed(index_list):
            minuend.pop(index)

    return None


# t05
def verify_sorted(numbers):
    """
    -------------------------------------------------------
    Determines whether a list is sorted.
    Use: in_order, index = verify_sorted(numbers)
    -------------------------------------------------------
    Parameters:
        numbers - a list of numbers (list)
    Returns:
        in_order - True if numbers is sorted, False otherwise (bool)
        index - index of first value not in order,
            -1 if in_order is True (int)
    ------------------------------------------------------
    """
    in_order = True
    index = -1

    for i in range(1, len(numbers)):
        if numbers[i] < numbers[i - 1]:
            in_order = False
            index = i
    return in_order, index
