"""
-------------------------------------------------------
[Assignment 7, Task 4]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-18"
-------------------------------------------------------
"""
# Imports
from functions import list_subtract

# Inputs
minuend = [5, 5, 4, 5]
subtrahend = [5]

# Outputs
print(f"Before subtraction: {minuend}")

list_subtract(minuend, subtrahend)

print(f"After subtraction: {minuend}")
