"""
-------------------------------------------------------
[Assignment 7, Task 1]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-18"
-------------------------------------------------------
"""
# Imports
from functions import list_factors

# Inputs
number = int(input("Enter an integer: "))
if number < 0:
    print("Must be a positive integer")

# Output
factor = list_factors(number)

print(factor)
