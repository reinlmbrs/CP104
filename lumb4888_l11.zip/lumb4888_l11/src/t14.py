"""
-------------------------------------------------------
[Lab 11, Task 14 ]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
# Imports
from functions import matrix_transpose

# Inputs
matrix = [[6, 4, 24], [1, -9, 8]]

# Outputs
transposed = matrix_transpose(matrix)
print(transposed)
