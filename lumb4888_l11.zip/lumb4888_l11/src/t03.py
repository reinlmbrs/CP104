"""
-------------------------------------------------------
[Lab 11, Task 3]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
# Imports
from functions import print_matrix_num, generate_matrix_num

# Inputs
rows = int(input("Number of rows in the list: "))
if rows < 0:
    print("Input must be a positive number")
cols = int(input("Number of columns: "))
if cols < 0:
    print("Input must be a positive number")
low = float(input("Low value of range: "))
high = float(input("High value of range: "))
if high < low:
    print("Input must be a larger number than low")
value_type = input("Types of values in the list: ")

# Outputs
print_matrix_num(generate_matrix_num(
    rows, cols, low, high, value_type), value_type)
