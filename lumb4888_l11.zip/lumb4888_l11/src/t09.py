"""
-------------------------------------------------------
[Lab 11, Task 9]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
# Imports
from functions import count_frequency

# Inputs
matrix = input("Enter the matrix to search in it: ")
char = input("Enter the character to search for it: ")

# Outputs
count = count_frequency(matrix, char)
print(count)
