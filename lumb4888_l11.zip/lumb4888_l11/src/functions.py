"""
-------------------------------------------------------
[Functions Module]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
# t01


def generate_matrix_num(rows, cols, low, high, value_type):
    """
    -------------------------------------------------------
    Generates a 2D list of numbers of the given type, 'float' or 'int'.
    (To generate random float number use random.uniform and to
    generate random integer number use random.randint)
    Use: matrix = generate_matrix_num(rows, cols, low, high, value_type)
    -------------------------------------------------------
    Parameters:
        rows - number of rows in the list (int > 0)
        cols - number of columns (int > 0)
        low - low value of range (float)
        high - high value of range (float > low)
        value_type - type of values in the list, 'float' or 'int' (str)
    Returns:
        matrix - a 2D list of random numbers (2D list of float/int)
    -------------------------------------------------------
    """
    import random

    matrix = []
    c = 0
    if value_type == "int":
        for i in range(rows):
            matrix.append([])

            for j in range(cols):
                matrix[c].append(random.randint(low, high))

            c = c + 1

    if value_type == "float":
        for k in range(rows):
            matrix.append([])
            for l in range(cols):
                matrix[c].append(random.uniform(low, high))
            c = c + 1

    return matrix


# t03
def print_matrix_num(matrix, value_type):
    """
    -------------------------------------------------------
    Prints the contents of a 2D list in a formatted table.
    Prints float values with 2 decimal points and prints row and
    column headings.
    Use: print_matrix_num(matrix, 'float')
    Use: print_matrix_num(matrix, 'int')
    -------------------------------------------------------
    Parameters:
        matrix - a 2D list of values (2D list)
        value_type - type of values in the list, 'float' or 'int' (str)
    Returns:
        None.
    -------------------------------------------------------
    """

    print(" ", end="")
    for i in range(len(matrix[0])):
        print("{:>11}".format(i), end="")
    print()

    if value_type == "int":
        for i in range(len(matrix)):
            print("{:>5}".format(i), end="")

            for j in range(len(matrix[i])):
                print("{:>10}".format(matrix[i][j]), end="")

            print()

    elif value_type == "float":
        for i in range(len(matrix)):
            print("{:>5}".format(i), end="")

            for j in range(len(matrix[i])):
                print("{:>10.2f}".format(float(matrix[i][j])), end="")

            print()
    return

# t06


def matrix_stats(matrix):
    """
    -------------------------------------------------------
    Returns statistics on a 2D list.
        Use: smallest, largest, total, average = matrix_stats(matrix)
    -------------------------------------------------------
    Parameters:
        matrix - a 2D list of numbers (2D list of float/int)
    Returns:
        smallest - the smallest number in matrix (float/int)
        largest - the largest number in matrix (float/int)
        total - the total of the numbers in matrix (float/int)
        average - the average of numbers in matrix (float/int)
    -------------------------------------------------------
    """

    smallest = min(min(row) for row in matrix)

    largest = max(max(row) for row in matrix)

    total = sum(sum(row) for row in matrix)

    average = total / (len(matrix) * len(matrix[0]))

    return smallest, largest, total, average

# t09


def count_frequency(matrix, char):
    """
    -------------------------------------------------------
    Count the number of appearances of the given character char
    in matrix.
    Use: count = count_frequency(matrix, char)
    -------------------------------------------------------
    Parameters:
        matrix - the matrix to search in it (2D list of str)
        char - character to search for it (str, len = 1)
    Returns:
        count - the number of appearances of char in the matrix (int)
    -------------------------------------------------------
    """
    rows = len(matrix)
    cols = len(matrix[0])
    count = 0

    for i in range(0, rows):
        for j in range(0, cols):
            if matrix[i][j] == char:
                count = count + 1

    return count


# t14
def matrix_transpose(matrix):
    """
    -------------------------------------------------------
    Transpose the contents of matrix. (Swap the rows and columns.)
    Use: transposed = matrix_transpose(matrix):
    -------------------------------------------------------
    Parameters:
        matrix - a 2D list (2D list of *)
    Returns:
        transposed - the transposed matrix (2D list of *)
    ------------------------------------------------------
    """
    c = 0
    i = 0
    transposed = []

    while len(matrix[0]) > i:
        row = []
        c = 0

        while len(matrix) > c:
            row.append(matrix[c][i])

            c = c + 1

        i = i + 1

        transposed.append(row)

    return transposed
