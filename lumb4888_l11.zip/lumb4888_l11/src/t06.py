"""
-------------------------------------------------------
[Lab 11, Task 6]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
# Imports
from functions import matrix_stats

# Inputs
matrix = [[2, 0, -1, 1], [10, 4, -5, 9], [-6, 3, 6, 0]]

# Outputs
smallest, largest, total, average = matrix_stats(matrix)
print(
    f"Smallest: {smallest}, Largest: {largest}, Total: {total}, Average: {average}")
