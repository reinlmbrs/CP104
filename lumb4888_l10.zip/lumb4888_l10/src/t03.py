"""
-------------------------------------------------------
[Lab 10, Task 3]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-23"
-------------------------------------------------------
"""
# Imports
from functions import customer_best

# Inputs
fh = open("customers.txt", "r")


# Outputs
result = customer_best(fh)
fh.close()
print(result)
