"""
-------------------------------------------------------
[Lab 10, Task 13]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-23"
-------------------------------------------------------
"""
# Imports
from functions import file_copy

# Inputs
fh_1 = open("words.txt", "r")
fh_2 = open("new_words.txt", "w")

# Outputs
file_copy(fh_1, fh_2)
fh_1.close()
fh_2.close()
print("Copying 'words.txt' to 'new_words.txt'")
