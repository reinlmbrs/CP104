"""
-------------------------------------------------------
[Computer Science]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-23"
-------------------------------------------------------
"""
# Imports
from functions import append_max_num

# Input
fh = open("numbers.txt", "r+")

# Outputs
num = append_max_num(fh)
fh.close()
print("file 'numbers.txt' open for reading and writing")
print(f"{num} is appended")
