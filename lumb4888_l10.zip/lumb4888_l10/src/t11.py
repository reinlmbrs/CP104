"""
-------------------------------------------------------
[Lab 10, Task 11]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-23"
-------------------------------------------------------
"""
# Imports
from functions import find_longest

# Input
fh = open("words.txt", "r")


# Output
word = find_longest(fh)
fh.close()

print("file 'words.txt' open for reading")
print(f"'{word}' is the last longest word")
