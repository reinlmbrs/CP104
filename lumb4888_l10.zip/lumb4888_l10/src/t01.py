"""
-------------------------------------------------------
[Lab 10, Task 1]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-23"
-------------------------------------------------------
"""
# Imports
from functions import customer_record

# Inputs
fh = open("customers.txt", "r")
n = int(input("Enter a record return: "))

# Outputs
result = customer_record(fh, n)
fh.close()
print(result)
