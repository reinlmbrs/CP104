"""
-------------------------------------------------------
[Lab 5, Task 2]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-19"
-------------------------------------------------------
"""
# Imports
from functions import get_weight

# Constants


# Inputs
mass = float(input("Mass of an object in kg: "))
if mass < 0:
    print("Mass must be over 0 kg ")

weight, message = get_weight(mass)

# Outputs
print(weight, message)
