"""
-------------------------------------------------------
[Lab 5, Task 14]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-20"
-------------------------------------------------------
"""
# Imports
from functions import ticket

price = ticket()

# Outputs
print(f"${price:.2f}")
