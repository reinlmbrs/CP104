"""
-------------------------------------------------------
[Lab 5, Task 11]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-19"
-------------------------------------------------------
"""
# Imports
from functions import quadrant

# Input
x = float(input("X coordinate on a Cartesian plane: "))
y = float(input("Y coordinate on a Cartesian plane: "))

location = quadrant(x, y)

# Output
print(location)
