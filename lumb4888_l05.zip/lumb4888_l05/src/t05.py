"""
-------------------------------------------------------
[Lab 5, Task 5]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-19"
-------------------------------------------------------
"""
# Imports
from functions import is_leap

# Input
year = int(input("Enter a year: "))
if year < 0:
    print("Year must be over 0 ")

result = is_leap(year)

# Outputs
print(result)
