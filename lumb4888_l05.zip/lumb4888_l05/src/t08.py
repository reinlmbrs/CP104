"""
-------------------------------------------------------
[Lab 5, Task 8]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-20"
-------------------------------------------------------
"""
# Imports
from functions import roman_numeral

# Inputs
n = int(input("Enter number to convert to Roman numerals: "))
if n > 10:
    print("Number must be between 1 and 10")

numeral = roman_numeral(n)

# Outputs
print(f"${numeral}")
