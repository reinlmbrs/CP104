"""
-------------------------------------------------------
[Lab 9, Task 4]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-17"
-------------------------------------------------------
"""
# Imports
from functions import validate_code

# Inputs
product_code = input("A product code: ")

# Outputs

category, digits, qualifiers = validate_code(product_code)

print(category, digits, qualifiers)
