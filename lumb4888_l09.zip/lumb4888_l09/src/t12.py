"""
-------------------------------------------------------
[Lab 9, Task 12]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-17"
-------------------------------------------------------
"""
# Imports
from functions import comma_period_replace

# Inputs
string = input("Enter a sentence: ")

# Outputs
out = comma_period_replace(string)

print(out)
