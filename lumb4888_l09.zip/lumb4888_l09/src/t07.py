"""
-------------------------------------------------------
[Lab 9, Task 7]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-17"
-------------------------------------------------------
"""
# Imports
from functions import vowel_count

# Inputs
s = input("Enter a sentence: ")

# Outputs
count = vowel_count(s)
print(f"Vowels: {count}")
