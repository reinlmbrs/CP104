"""
-------------------------------------------------------
[Lab 9, Task 10]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-17"
-------------------------------------------------------
"""
# Imports
from functions import text_analyze

# Inputs
txt = input("Enter a text to be analyzed: ")

# Outputs
uppr, lowr, dgts, whtspc = text_analyze(txt)

print(
    f"Uppercase letters: {uppr}, Lowercase letters: {lowr}, Digits: {dgts}, Spaces: {whtspc}")
