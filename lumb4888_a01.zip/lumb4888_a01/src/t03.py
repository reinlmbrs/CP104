"""
-------------------------------------------------------
[Assignment 1, Task 3]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------
"""
# Imports

# Constants
M_TO_KM = 1.61

# Input
miles = float(input("Enter lengths in miles: "))

# Calculations
kilometeres = float(miles * M_TO_KM)

# Outputs
print("Length in km: ", kilometeres)
