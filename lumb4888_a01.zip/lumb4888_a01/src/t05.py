"""
-------------------------------------------------------
[Assignment 1, Task 5]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-09-29"
-------------------------------------------------------
"""
# Inputs
principal = float(input("Principal: $"))
interest = float(input("Interest (%): "))
years = int(input("Number of years: "))
interest_compounded = int(
    input("Number of times interest compounded per year: "))

# Calculation
# Converting the annual interest rate into decimal
interest_decimal = float(interest / 100)

brackets = 1 + (interest_decimal / interest_compounded)
exponent = interest_compounded * years
balance = (principal * (brackets) ** exponent)

# Output
print(f"Balance: ${balance}")
