"""
-------------------------------------------------------
[Assignment 1, Task 2]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-09-20"
-------------------------------------------------------
"""
# Input
age = input("What is your age? ")
favourite_band = input("What is your favourite band? ")

# Output
print("I am", age, "years old and", favourite_band, "is my favourite band.")
