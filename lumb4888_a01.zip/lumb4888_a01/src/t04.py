"""
-------------------------------------------------------
[Assignment 1, Task 4]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------
"""
# Inputs
cost_dosa = float(input("Cost of 1 dosa: "))
number_dosa = int(input("Number of dosa: "))

# Calculations
total_cost = float(cost_dosa * number_dosa)

# Outputs
print(f"Total cost of 3 dosas: ${total_cost}")
