"""
-------------------------------------------------------
[Functions Module]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
# t01


def total_wins():
    """
    -------------------------------------------------------
    Enter a series of strings that represent the output of 
    a game with a loop. The program returns two numbers
    that represent how many times the string "purple" and 
    "gold" appeared in the input.
    Use:  purple_wins, gold_wins = total_wins()
    -------------------------------------------------------
    Returns:
        purple, gold - number of times the team has won (int)
    ------------------------------------------------------
    """
    purple = 0
    gold = 0

    team = input("Enter the winning team: ")
    while team != "":
        if team == "purple":
            purple = purple + 1

        elif team == "gold":
            gold = gold + 1

        team = input("Enter the winning team: ")

    return purple, gold

# t02


def detect_prime(number):
    """
    -------------------------------------------------------
    Determines if number is a prime number.
    Use: prime = detect_prime(number)
    -------------------------------------------------------
    Parameters:
        number - an integer (int > 1)
    Returns:
        prime - True if number is prime, False otherwise (bool)
    ------------------------------------------------------
    """
    i = 2

    while i <= number // 2:
        if number % i == 0:
            prime = False
        i += 1

    if number <= 1:
        prime = False
    else:
        prime = True

    return prime


# t03
def interest_table(principal_amount, interest_rate, payment):
    """
    -------------------------------------------------------
    Prints a table of monthly interest and payments on a loan.
    Use: interest_table(principal_amount, interest_rate, payment)
    -------------------------------------------------------
    Parameters:
        principal_amount - original value of a loan (float > 0)
        interest_rate - yearly interest interest_rate as a % (float >= 0)
        payment - the monthly payment (float > 0)
    Returns:
        None
    ------------------------------------------------------
    """
    months = 1
    month_percent = (interest_rate / 100 / 12)
    dash = "-"

    print(f"Principal: ${principal_amount:.2f}")
    print(f"Interest rate: {interest_rate:.2f}%")
    print(f"Monthly payment: ${payment:.2f}")
    print(dash * 35)
    print(f'{"Month":>5}{"Interest":>10}{"Payment":>10}{"Balance":>10}')
    print(dash * 35)

    while principal_amount > 0:
        interest_value = principal_amount * month_percent

        principal_amount = (principal_amount - payment + interest_value)

        if principal_amount < 0:
            payment = payment + principal_amount
            principal_amount = 0

        print(
            f'{months:>5}{interest_value:>10.2f}{payment:>10.2f}{principal_amount:>10.2f}')

        months += 1

    else:
        return None


# t04
def count_of_digits(number):
    """
    -------------------------------------------------------
    Counts the number of digits in an integer.
    Use: digits = count_of_digits(number)
    -------------------------------------------------------
    Parameters:
        number - an integer (int)
    Returns:
        digits - the number of digits in number (int)
    ------------------------------------------------------
    """
    digits = 0

    while number != 0:
        number = number // 10
        digits += 1

    return digits


# t05
def factor_summation(number):
    """
    -------------------------------------------------------
    Determines the sum of factors of an integer not including
    the integer itself. An integer's factors are the whole numbers
    that the integer can be evenly divided by.
    Use: total = factor_summation(number)
    -------------------------------------------------------
    Parameters:
        number - a positive integer (int >= 1)
    Returns:
        total - the total of number's factors (int)
    ------------------------------------------------------
    """
    total = 0
    n = 1

    while n <= number // 2:
        if number % n == 0:
            total += n
        n += 1

    return total
