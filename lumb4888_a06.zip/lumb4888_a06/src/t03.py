"""
-------------------------------------------------------
[Assignment 6, Task 3]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
# Imports
from functions import interest_table
# Input
principal_amount = float(input("Original value of the loan: "))
if principal_amount < 0:
    print("Value must positive")

interest_rate = float(input("Yearly interest: "))
if interest_rate <= 0:
    print("Interest cannot equal 9 and must be positive")

payment = float(input("The monthly pay: "))
if payment < 0:
    print("Payment must positive")

# Output

interest_table(principal_amount, interest_rate, payment)
