"""
-------------------------------------------------------
[Assignment 6, Task 5]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
# Imports
from functions import factor_summation

# Inputs
number = int(input("Enter a positive integer: "))
if number <= 0:
    print("Integer must be positive")

# Outputs
total = factor_summation(number)
print(total)
