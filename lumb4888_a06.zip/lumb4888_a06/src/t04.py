"""
-------------------------------------------------------
[Assignment 6, Task 4]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
# Imports
from functions import count_of_digits

# Inputs
number = int(input("Enter an integer: "))

# Outputs
digits = count_of_digits(number)

print(digits)
