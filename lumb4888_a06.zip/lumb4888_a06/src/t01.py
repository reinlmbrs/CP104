"""
-------------------------------------------------------
[Assignment 6, Task 1]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
# Imports
from functions import total_wins
# Constants

purple, gold = total_wins()

print(f"Purple wins: {purple}, Gold wins: {gold}")
