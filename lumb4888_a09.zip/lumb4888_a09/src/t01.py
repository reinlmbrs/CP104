"""
-------------------------------------------------------
[Assignment 9, Task 1]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""
# Imports
from functions import file_top

# Inputs
file_handle = open("students.txt", "r", encoding="utf-8")

# Outputs
file_top(file_handle, 5)
file_handle.close()
