"""
-------------------------------------------------------
[Assignment 9, Task 3]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""
# Imports
from functions import file_statistics
# Input
file_handle = open("addresses.txt", "r", encoding="utf-8")

# Output
ucount, lcount, dcount, wcount, rcount = file_statistics(file_handle)
print(ucount, lcount, dcount, wcount, rcount)
