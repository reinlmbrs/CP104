"""
-------------------------------------------------------
[Assignment 9, Task 2]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""
# Imports
from functions import read_integers
# Inputs
file_handle = open("numbers.txt", "r", encoding="utf-8")

# Outputs
number_list = read_integers(file_handle)
file_handle.close()
print(number_list)
