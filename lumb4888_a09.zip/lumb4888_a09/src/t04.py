"""
-------------------------------------------------------
[Assignment 9, Task 4]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""
# Imports
from functions import line_numbering

# Constants
filename = "wilde.txt"
new_filename = "wilde_numbered.txt"

fh_read = open(filename, "r", encoding="utf-8")
fh_write = open(filename, "w", encoding="utf-8")

line_numbering(fh_read, fh_write)
