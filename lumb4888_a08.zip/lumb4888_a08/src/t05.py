"""
-------------------------------------------------------
[Assignment 8, Task 5]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
# Imports
from functions import has_word_chain

# Input
words = input("Enter a list of strings: ")

# Outputs
word_chain = has_word_chain(words)
print(word_chain)
