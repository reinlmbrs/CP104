"""
-------------------------------------------------------
[Assignment 8, Task]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
# Imports
from functions import add_spaces

# Inputs
print("Write a sentence in which all the words are run together (no spaces), but the first character of each word is uppercase.")
sentence = input("Enter a sentence: ")

# Outputs
spaced = add_spaces(sentence)
print(spaced)
