"""
-------------------------------------------------------
[Assignment 8, Task 2]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
# Imports
from functions import pluralize

# Inputs
string = input("A string: ")

# Outputs
pluralized = pluralize(string)
print(pluralized)
