"""
-------------------------------------------------------
[Assignment 8, Task 4]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
# Imports
from functions import valid_isbn

# Input
isbn = input("Enter ISBN: ")

# Outputs
is_valid = valid_isbn(isbn)

print(is_valid)
