"""
-------------------------------------------------------
[Assignment 8, Task 3]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
# Imports
from functions import common_end

# Inputs
str1 = input("Enter first string for ending comparison: ")
str2 = input("Enter second string for ending comparison: ")


# Outputs
suffix = common_end(str1, str2)
print(suffix)
