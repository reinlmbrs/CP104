"""
-------------------------------------------------------
[Functions Module]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""


# t01
def calc_factorial(number):
    """
    -------------------------------------------------------
    Calculates and returns the factorial of number.
    Use: product = calc_factorial(number)
    -------------------------------------------------------
    Parameters:
        number - number to factorial (int > 0)
    Returns:
        product - number! (int)
    ------------------------------------------------------
    """

    product = 1

    for i in range(1, number+1):
        product = product * i

    return product

# t02


def calories_treadmill(per_min, minutes):
    """
    -------------------------------------------------------
    Calculates  the number of calories burned every five 
    minutes given the number of calories burned per minute
    and the total number of minutes ran.
    Use: calories = calories_treadmill(per_min, minutes)
    -------------------------------------------------------
    Parameters:
        per_min - number of calories burned per minute (float > 0)
        minutes - total number of minutes ran (int > 0)
    Returns:
        None
    ------------------------------------------------------
    """
    calories = None

    for i in range(5, minutes+1, 5):
        calories = float(per_min * i)
        print(f"{i}\t{calories:.1f}")

    return None


# t03
def arrow_up(rows):
    """
    -------------------------------------------------------
    takes an integer parameter and prints a arrow of # 
    characters pointing up.
    Use: arrow_up(rows)
    -------------------------------------------------------
    Parameters:
        rows - amount of rows (int > 0)
    Returns:
        None
    ------------------------------------------------------
    """
    CHARACTER = "#"

    for i in range(1, rows + 1):
        space1 = " " * (rows - i)
        if i == 1:
            print(space1 + CHARACTER)
        else:
            space2 = " " * (2 * (i - 1) - 1)
            print(space1 + CHARACTER + space2 + CHARACTER)

    return None


# t04
def multiplication_table(start_num, stop_num):
    """
    -------------------------------------------------------
    Prints a multiplication table for values from start_num to stop_num.
    Use: multiplication_table(start_num, stop_num)
    -------------------------------------------------------
    Parameters:
        start_num - the range start value (int)
        stop_num - the range stop value (int)
    Returns:
        None
    ------------------------------------------------------
    """
    num = 0

    for i in range(start_num, stop_num+1, 1):
        print(f"{i:>5}", end="")
        num += 1

    dash = num * 5
    print()
    print("          "+"-" * dash)

    for i in range(start_num, stop_num+1, 1):
        print(f"{i:>5} |", end="")

        for h in range(start_num, stop_num+1):
            print(f"{i*h:>5}", end="")

        print()

    return None


# t05
def range_addition(start, increment, count):
    """
    -------------------------------------------------------
    Uses a for loop to sum values from start by increment.
    Use: total = range_addition(start, increment, count)
    -------------------------------------------------------
    Parameters:
        start - the range start value (int)
        increment - the range increment (int)
        count - the number of values in the range (int)
    Returns:
        total - the sum of the range (int)
    ------------------------------------------------------
    """

    total = 0

    for i in range(count):
        total += start
        start += increment

    return total
