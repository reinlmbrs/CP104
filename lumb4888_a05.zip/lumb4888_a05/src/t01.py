"""
-------------------------------------------------------
[Assignment 5, Task 1]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
# Imports
from functions import calc_factorial

# Inputs
number = int(input("Number to factorial: "))
if number < 0:
    print("Number must be a positive integer")

# Outputs
product = calc_factorial(number)

print(f"{number}! = {product}")
