"""
-------------------------------------------------------
[Computer Science]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
# Imports
from functions import multiplication_table

# Inputs
start_num = int(input("The range start value: "))
stop_num = int(input("The range stop value: "))
