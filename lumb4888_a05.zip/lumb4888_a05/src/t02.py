"""
-------------------------------------------------------
[Assignment 5, Task 2]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
# Imports
from functions import calories_treadmill

# Input
per_min = float(input("Number of calories burned per minute: "))
if per_min < 0:
    print("Must be a positive integer")

minutes = int(input("Total number of minutes ran: "))
if minutes < 0:
    print("Must be a positive integer")

# Output

calories = calories_treadmill(per_min, minutes)
