"""
-------------------------------------------------------
[Assignment 5, Task 5]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
# Imports
from functions import range_addition

# Inputs
start = int(input("The range start value: "))
increment = int(input("The range increment: "))
count = int(input("The number of values in the range: "))

# Output
total = range_addition(start, increment, count)
print(
    f"The sum of {count} values starting from {start} with an increment of {increment} is {total}")
