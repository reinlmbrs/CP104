"""
-------------------------------------------------------
[Assignment 5, Task 3]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
# Imports
from functions import arrow_up

# Inputs
rows = int(input("Enter number of rows: "))
if rows < 0:
    print("Rows must be a positive integer")
