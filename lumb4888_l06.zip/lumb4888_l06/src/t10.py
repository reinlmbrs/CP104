"""
-------------------------------------------------------
[Lab 6, Task 10]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-27"
-------------------------------------------------------
"""
# Imports
from functions import treadmill

# Inputs
burnt_per_minute = float(input("Enter calories burnt per minute: "))
if burnt_per_minute < 0:
    print("Integer must be positive")

start = int(input("Start time in minutes: "))
if start < 0:
    print("Start time must be a positive integer")

end = int(input("End time in minutes: "))
if end <= start:
    print("End time must be a larger number than start time")

inc = int(input("Increments in minutes: "))

# Output

treadmill(burnt_per_minute, start, end, inc)
