"""
-------------------------------------------------------
[Lab 6, Task 2]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-27"
-------------------------------------------------------
"""
# Imports
from functions import sum_odd

# Inputs
num = int(input("Enter an integer: "))
if num < 0:
    print("Integer must be positive ")


# Outputs
total = sum_odd(num)

print('The sum of all odd numbers from from 1 to {} is: {} '.format(num, total))
