"""
-------------------------------------------------------
[Lab 6, Task 15]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-27"
-------------------------------------------------------
"""
# Imports
from functions import statistics

# Inputs
n = int(input("Enter number of values to process: "))
if n < 0:
    print("Must be a positive integer")

# Outputs
minimum, maximum, total, average = statistics(n)

print(
    f"Minimum: {minimum}, Maximum: {maximum}, Total: {total}, Average: {average}")
