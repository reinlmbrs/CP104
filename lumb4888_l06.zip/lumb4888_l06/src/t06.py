"""
-------------------------------------------------------
[Lab 6, Task 6]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-27"
-------------------------------------------------------
"""
# Imports
from functions import draw_triangle

# Inputs
height = int(input("Enter number of characters high: "))
if height < 0:
    print("Integer must be positive ")

char = input("Enter character to draw with: ")

draw_triangle(height, char)
