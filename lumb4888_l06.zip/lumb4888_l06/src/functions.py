"""
-------------------------------------------------------
[Functions]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-27"
-------------------------------------------------------
"""


# t02

def sum_odd(num):
    """
    -------------------------------------------------------
    Sums and returns the total of all odd numbers from 1 to num (inclusive).
    Use: total = sum_odd(num)
    -------------------------------------------------------
    Parameters:
        num - an integer (int > 0)
    Returns:
        total - sum of all odd numbers from 1 to num (int)
    ------------------------------------------------------
    """
    total = 0

    for i in range(1, num + 1, 2):
        total += i

    return total


# t06

def draw_triangle(height, char):
    """
    -------------------------------------------------------
    Prints a triangle of height characters using
    the char character.
    Use: draw_triangle(height, char)
    -------------------------------------------------------
    Parameters:
        height - number of characters high (int > 0)
        char - the character to draw with (str, len() == 1)
    Returns:
        None
    ------------------------------------------------------
    """

    if height <= 0:
        return None
    else:
        for i in range(1, height+1):
            space = (height - i) * ' '
            print(space + char * (2*i-1))


# t10

def treadmill(burnt_per_minute, start, end, inc):
    """
    -------------------------------------------------------
    Calculates and prints calories burnt on a treadmill over
    a given time range.
    Use: treadmill(burnt_per_minute, start, end, inc)
    -------------------------------------------------------
    Parameters:
        burnt_per_minute - calories burnt per minute (float > 0)
        start - start time in minutes (int > 0)
        end - end time in minutes (int >= start)
        inc - increment in minutes (int > 0)
    Returns:
        None
    ------------------------------------------------------
    """
    if start < 0:
        return None
    else:
        for i in range(start, end+1, inc):
            cals_burned = burnt_per_minute * i
            print(f"Calories burned after {i} minutes: {cals_burned} ")


# t12

def gic(value, years, rate):
    """
    -------------------------------------------------------
    Calculates and prints a table of how much a GIC (Guaranteed
    Income Certificate) is worth over a number of years, and
    returns its final value.
    Use: final_value = gic(value, years, rate)
    -------------------------------------------------------
    Parameters:
        value - GICs initial value (int > 0)
        years - number of years to maturity (int > 0)
        rate - percent increase value per year (float > 0)
    Returns:
        final_value - the final value of the GIC (float)
    ------------------------------------------------------
    """
    print(f"{'Year':<5}{'Value $':>15}")
    print(f"{'-':-^20}")
    print(f"{'0':<5}{value:>14,.2f}")

    for i in range(1, years + 1, 1):
        value = (value * (1+rate/100))
        final_value = value
        print(f"{i:<5}{final_value:>14,.2f}")

    return final_value

# t15


def statistics(n):
    """
    -------------------------------------------------------
    Asks a user to enter n values, then calculates and returns
    the minimum, maximum, total, and average of those values.
    Use: minimum, maximum, total, average = statistics(n)
    -------------------------------------------------------
    Parameters:
        n - number of values to process (int > 0)
    Returns:
        minimum - smallest of n values (float)
        maximum - largest of n values (float)
        total - total of n values (float)
        average - average of n values (float)
    ------------------------------------------------------
    """
    value1 = float(input("First Value: "))
    maximum = value1
    minimum = value1
    total = value1

    for i in range(n-1):
        value2 = float(input("Next Value: "))

        if value2 < minimum:
            minimum = value2

        elif value2 > maximum:
            maximum = value2

        total += value2

    average = float(total/n)

    return minimum, maximum, total, average
