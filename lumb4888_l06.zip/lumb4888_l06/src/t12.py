"""
-------------------------------------------------------
[Lab 6, Task 12]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-27"
-------------------------------------------------------
"""
# Imports
from functions import gic

# Inputs
value = int(input("Enter GICs initial value: "))
if value < 0:
    print("Value must be a positive integer")

years = int(input("Enter number of years to maturity: "))
if value < 0:
    print("Year must be a positive integer")

rate = float(input("Enter percent increase value per year: "))
if rate < 0:
    print("Rates must be a positive integer")

# Outputs
final_value = gic(value, years, rate)

print(f"{'Final Value: ':<5}${final_value:.2f}")
