"""
-------------------------------------------------------
[Lab 7, Task 5]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from functions import positive_statistics

# Outputs

minimum, maximum, total, average = positive_statistics()

print(minimum, maximum, total, average)
