"""
-------------------------------------------------------
[Lab 7, Task 2]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from functions import power_of_two

# Input
target = int(input("Value to find nearest power of two: "))
if target < 0:
    print("Value must be greater than 0")

# Outputs
power = power_of_two(target)

print(power)
