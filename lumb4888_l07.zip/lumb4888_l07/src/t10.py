"""
-------------------------------------------------------
[Lab 7, Task 10]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from functions import employee_payroll

# Output
total, average = employee_payroll()

print(
    f"Total net employee wages: ${total:.2f}, Average employee net wages: ${average:.2f}")
