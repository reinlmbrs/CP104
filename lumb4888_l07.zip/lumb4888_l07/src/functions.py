"""
-------------------------------------------------------
[Functions Module]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""

# t01
from random import randint


def hi_lo_game(high):
    """
    -------------------------------------------------------
    Plays a random higher-lower guessing game.
    Use: count = hi_lo_game(high)
    -------------------------------------------------------
    Parameters:
        high - maximum random value (int > 1)
    Returns:
        count - the number of guesses the user made (int)
    -------------------------------------------------------
    """
    number = randint(1, high)

    count = 0

    while high != number:
        high = int(input("Guess: "))
        if high > number:
            print("Too high, try again.")
            count = count + 1
        elif high < number:
            print("Too low, try again.")
            count = count + 1
        else:
            print(
                f"Congratulations - good guess!\nYou made {count} guesses.")
            count = count + 1

    return count


# t02
def power_of_two(target):
    """
    -------------------------------------------------------
    Determines the nearest power of 2 greater than or equal to
    a given target.
    Use: power = power_of_two(target)
    -------------------------------------------------------
    Parameters:
        target - value to find nearest power of 2 (int >= 0)
    Returns:
        power - first power of 2 >= target (int)
    -------------------------------------------------------
    """
    power = 1

    while target > power:
        power *= 2

    return power


# t05
def positive_statistics():
    """
    -------------------------------------------------------
    Asks a user to enter a series of positive numbers, then calculates
    and returns the minimum, maximum, total, and average of those numbers.
    Stop processing values when the user enters a negative number.
    The first number entered must be positive.
    Use: minimum, maximum, total, average = positive_statistics()
    -------------------------------------------------------
    Returns:
        minimum - smallest of the entered values (float)
        maximum - largest of the entered values (float)
        total - total of the entered values (float)
        average - average of the entered values (float)
    ------------------------------------------------------
    """

    value = float(input("First positive value: "))

    minimum = value
    maximum = value
    total = value
    n = 1
    value = float(input("Next positive value: "))

    while value >= 0:
        if value < minimum:
            minimum = value
        if value > maximum:
            maximum = value

        total += value
        n += 1

        value = float(input("Next positive value: "))

    if n > 0:
        average = total / n

    return minimum, maximum, total, average


# t07
def meal_costs():
    """
    -------------------------------------------------------
    Asks a user the costs of breakfast, lunch, and supper for each
    day the user was away. Assumes there is at least one day, and
    after entering data for each day asks the user whether they want
    to enter data for another day. Calculates total costs for meals.
    Use: b_total, l_total, s_total, a_total = meal_costs()
    -------------------------------------------------------
    Returns:
        b_total - total breakfasts cost (float)
        l_total - total lunches cost (float)
        s_total - total suppers cost (float)
        a_total - all meals cost (float)
    ------------------------------------------------------
    """
    b_total = 0
    l_total = 0
    s_total = 0
    a_total = 0
    n = 1

    print(f"For Day {n}")
    b_total1 = float(input("How much was breakfast? $"))
    l_total1 = float(input("How much was lunch? $"))
    s_total1 = float(input("How much was supper? $"))

    b_total += b_total1
    l_total += l_total1
    s_total += s_total1

    a_total = float(b_total1 + l_total1 + s_total1)

    print(f"Your total for the day was ${a_total:.2f}")

    data = input("Were you away another day (Y/N)? ")

    while data == "Y":
        n = n + 1
        print(f"For Day {n}")
        b_total1 = float(input("How much was breakfast? $"))
        l_total1 = float(input("How much was lunch? $"))
        s_total1 = float(input("How much was supper? $"))

        a_total1 = float(b_total1 + l_total1 + s_total1)

        print(f"Your total for the day was ${a_total1:.2f}")
        data = input("Were you away another day (Y/N)? ")

        b_total += b_total1
        l_total += l_total1
        s_total += s_total1
        a_total += a_total1

    return b_total, l_total, s_total, a_total


# t10
def employee_payroll():
    """
    -------------------------------------------------------
    Calculates and returns the weekly employee payroll for all employees
    in an organization. For each employee, ask the user for the employee ID
    number, the hourly wage rate, and the number of hours worked during a week.
    An employee number of zero indicates the end of user input.
    Each employee is paid 1.5 times their regular hourly rate for all hours
    over 40. A tax amount of 3.625 percent of gross salary is deducted.
    Use: total, average = employee_payroll()
    -------------------------------------------------------
    Returns:
        total - total net employee wages (i.e. after taxes) (float)
        average - average employee net wages (float)
    ------------------------------------------------------
    """
    TAX_AMOUNT = 0.03625
    OVERTIME_RATE = 1.5
    OVERTIME = 40

    total = 0
    average = 0
    n = 0  # number of employees

    employee = int(input("Enter your employee ID number: "))
    while employee != 0:
        hourly_wage = float(input("Hourly wage: "))
        hours_work = float(input("Hours worked during the week: "))
        if hours_work <= OVERTIME:
            pay = float(hours_work * hourly_wage)
        else:
            pay = float(OVERTIME * hourly_wage) + \
                (hours_work - OVERTIME) * (hourly_wage) * OVERTIME_RATE

        net_wage = float(pay * (1 - TAX_AMOUNT))

        print(f"Net Payment for employee {employee}: ${net_wage:.2f}")

        total += net_wage
        n += 1

        employee = int(input("Enter your employee ID number: "))

    if n > 0:
        average = total / n

    return total, average
