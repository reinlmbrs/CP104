"""
-------------------------------------------------------
[Lab 7, Task 7]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from functions import meal_costs

# Outputs
b_total, l_total, s_total, a_total = meal_costs()

print(f"{b_total:.2f}, {l_total:.2f}, {s_total:.2f}, {a_total:.2f}")
