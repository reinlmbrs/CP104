"""
-------------------------------------------------------
[Lab 7, Task 1]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from functions import hi_lo_game

# Input
high = int(input("Maximum random value: "))
if high < 1:
    print("Value must be over 1")

# Outputs
count = hi_lo_game(high)
