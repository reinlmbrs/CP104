"""
-------------------------------------------------------
[Lab 8, Task 1]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-09"
-------------------------------------------------------
"""
# Imports
from functions import get_weekday_name

# Inputs
d = int(input("Enter the day of week number: "))
if d < 1 or d > 7:
    print("Invalid Integer")

# Output
name = get_weekday_name(d)

print(name)
