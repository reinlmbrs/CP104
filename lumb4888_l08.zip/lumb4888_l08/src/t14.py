"""
-------------------------------------------------------
[Lab 8, Task 14]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports
from functions import intersection

# Inputs
source1 = input("A list: ")
source2 = input("A list: ")

# Output
target = intersection(source1, source2)

print(target)
