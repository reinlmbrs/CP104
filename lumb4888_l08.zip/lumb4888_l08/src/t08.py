"""
-------------------------------------------------------
[Lab 8, Task 8]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports
from functions import linear_search

# Inputs
values = input("A list of values: ")
value = input("Can be compared to items in values: ")


# Outputs
index = linear_search(values, value)

print(index)
