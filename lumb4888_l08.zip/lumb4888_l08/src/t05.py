"""
-------------------------------------------------------
[Lab 8, Task 5]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports
from functions import get_lotto_numbers

# Inputs
n = int(input("Number of lottery numbers to generate: "))
if n < 0:
    print("Must be a positive integer")
low = int(input("Low value of the lottery number range: "))
if low <= 0:
    print("Must be a positive integer or cannot equal 0")
high = int(input("High value of the lottery: "))
if high < low:
    print("Integer must be a bigger than the low value")

# Outputs
numbers = get_lotto_numbers(n, low, high)

print(numbers)
