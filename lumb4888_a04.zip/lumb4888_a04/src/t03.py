"""
-------------------------------------------------------
[Assignment 4, Task 3]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-28"
-------------------------------------------------------
"""
# Imports
from functions import largest_average

# Constants
val1 = float(input("Enter a number: "))
val2 = float(input("Enter a number: "))
val3 = float(input("Enter a number: "))

# Output
average = largest_average(val1, val2, val3)

print(f"The average of the two largest values is: {average}")
