"""
-------------------------------------------------------
[Assignment 4, Task 4]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-28"
-------------------------------------------------------
"""
# Imports
from functions import colour_combine

# Inputs
rgb_colour1 = input("Enter a primary RGB rgb_colour: ")
rgb_colour2 = input("Enter a primary RGB rgb_colour: ")

# Outputs
rgb_colour = colour_combine(rgb_colour1, rgb_colour2)

print(rgb_colour)
