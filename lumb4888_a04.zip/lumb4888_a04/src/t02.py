"""
-------------------------------------------------------
[Assignment 4, Task 2]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-28"
-------------------------------------------------------
"""
# Imports
from functions import pollution_ranking

# Inputs
air_quality_index = int(input("Enter air quality index: "))

# Output
pollution = pollution_ranking(air_quality_index)

print(pollution)
