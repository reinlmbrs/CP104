"""
-------------------------------------------------------
[Assignment 4, Task 5]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-28"
-------------------------------------------------------
"""
# Imports
from functions import hoo_rah

# Input
number = int(input("Enter an integer: "))

# Outputs
message = hoo_rah(number)

print(message)
