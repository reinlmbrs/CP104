"""
-------------------------------------------------------
[Assignment 4, Task 1]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-28"
-------------------------------------------------------
"""
# Imports
from functions import day_name

# Inputs
day_num = int(input("Enter the day number: "))
if day_num < 1:
    print("Days must be between 1 and 7")
elif day_num > 7:
    print("Days must be between 1 and 7")


# Outputs
day = day_name(day_num)

print(day)
