"""
-------------------------------------------------------
[Assignment 3, Task 2]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-21"
-------------------------------------------------------
"""
# Imports
from functions import lawn_mow_time

# Inputs
width = float(input("Enter the width of the lawn in meters: "))
if width < 0:
    print("Width must be a positive integer ")

length = float(input("Enter length of lawn in meters: "))
if length < 0:
    print("Length must be a positive integer ")

speed = float(input("Enter the square meters cut per minute: "))
if speed < 0:
    print("Speed must be a positive integer ")

# Outputs
time = lawn_mow_time(width, length, speed)

print(f"How long it takes to mow the lawn: {time} ")
