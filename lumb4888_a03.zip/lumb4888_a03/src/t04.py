"""
-------------------------------------------------------
[Assignment 3, Task 4]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-21"
-------------------------------------------------------
"""
# Imports
from functions import multiply_fractions

# Inputs
num1 = int(input("Numerator of first fraction: "))
den1 = int(input("Denominator of first fraction: "))
if den1 == 0:
    print("Denominator cannot equal 0 ")
num2 = int(input("Numerator of second fraction: "))
den2 = int(input("Denominator of second fraction: "))
if den2 == 0:
    print("Denominator cannot equal 0 ")

# Outputs
num, den, product = multiply_fractions(num1, den1, num2, den2)

print(num, den, product)
