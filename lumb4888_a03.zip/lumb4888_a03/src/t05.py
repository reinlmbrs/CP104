"""
-------------------------------------------------------
[Assignment 3, Task 5]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-21"
-------------------------------------------------------
"""
# Imports
from functions import falling_distance

# Inputs
falling_time = int(input("Enter the time object has fallen in seconds: "))
if falling_time <= 0:
    print("Time must be a positive integer")

# Outputs
distance = falling_distance(falling_time)

print(f"The distance the object has fallen: {distance}")
