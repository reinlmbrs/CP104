"""
-------------------------------------------------------
[Assignment 3, Task 1]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-21"
-------------------------------------------------------
"""
# Imports
from functions import footage_to_acres

# Inputs
square_feet = float(input("Enter area in square feet: "))
if square_feet <= 0:
    print("Must be a positive integer ")


# Outputs
acres = footage_to_acres(square_feet)

print(f"Acres: {acres} ")
