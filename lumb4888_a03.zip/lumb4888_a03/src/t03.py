"""
-------------------------------------------------------
[Assignment 3, Task 3]
-------------------------------------------------------
Author:  Rein Lumbres
ID:      169064888
Email:   lumb4888@mylaurier.ca
__updated__ = "2023-10-21"
-------------------------------------------------------
"""
# Imports
from functions import extract_date

# Inputs
date_number = int(input("Enter a date number in the format YYYYMMDD: "))

# Outputs
year, month, day = extract_date(date_number)

print(year, month, day)
